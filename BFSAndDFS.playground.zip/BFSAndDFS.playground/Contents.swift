//: Playground - noun: a place where people can play

import UIKit
protocol Search {
    func maxGenerations() -> Int
    func mostRecentAncestor(named: String) -> Person?
}
class Person: Search {
    var name: String
    var left: Person?
    var right: Person?
    init(name: String, left: Person? = nil, right: Person? = nil) {
        self.name = name;
        self.left = left;
        self.right = right;
    }
    func maxGenerations() -> Int {
        //TODO
        return 0
    }
    func mostRecentAncestor(named: String) -> Person? {
        //TODO
        return nil
    }
}

let johnJunior = Person(name: "John Junior")
let nancy = Person(name: "Nancy")
let robert = Person(name: "Robert")
let marie = Person(name: "Marie")
let ruth = Person(name: "Ruth")
let johnSenior = Person(name: "John Senior")
let leila = Person(name: "Leila")
let herbert = Person(name: "Herbert")
let dianne = Person(name: "Dianne")
let doug = Person(name: "Doug")
let mark = Person(name: "Mark")

mark.left = dianne
mark.right = doug

dianne.left = ruth
dianne.right = johnSenior

doug.left = leila
doug.right = herbert

ruth.left = nancy

leila.left = marie

herbert.right = robert

robert.right = johnJunior



